/*
 * version.h - version information for xpostit+
 * Note:  the VERSION value must be a string!
 * 
 */
#define VERSION	"2.3b2"
